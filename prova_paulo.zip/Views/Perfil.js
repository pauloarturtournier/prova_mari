import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, ScrollView } from 'react-native';
import { Titulo } from '../Componentes/Titulo';

export default function Perfil() {
  return (
    <ScrollView style={styles.background}>
      <View style={styles.container}>
        <Titulo />
        
        <Text style={styles.red1}>joaquim</Text>

    <Image source={require('../assets/Penguin.jpg')} style={styles.image} />
 <Image source={require('../assets/1.jpg')} style={styles.image} />
    <Image source={require('../assets/2.jpg')} style={styles.image} />
        <Image source={require('../assets/3.jpg')} style={styles.image} />
        <Image source={require('../assets/4.jpg')} style={styles.image} />

        <Text style={styles.textWhite}>idade: 18 anos</Text>
        <Text style={styles.textWhite}>abatedor</Text>
        <Text style={styles.textWhite}>joaquim é um cara legal</Text>

        <StatusBar style="light" />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    backgroundColor: '#000', 
  },
  container: {
    marginTop: 50,
    alignItems: 'center',
    paddingBottom: 30,
  },
  red1: {
    color: 'red',
    fontWeight: 'bold',
    fontSize: 50,
    textAlign: 'center',
    marginBottom: 10,
  },
  image: {
    width: 200,
    height: 200,
    borderRadius: 10,
    marginBottom: 15,
    resizeMode: 'cover',
  },
  textWhite: {
    color: '#fff',
    fontSize: 20,
    marginTop: 5,
  },
});