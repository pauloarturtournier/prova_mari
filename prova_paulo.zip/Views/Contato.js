
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, TextInput, View, TouchableOpacity } from 'react-native';
import { Titulo } from '../Componentes/Titulo';

const Contato = () => {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [mensagem, setMensagem] = useState('');

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Contato</Text>

      <View style={styles.form}>
        <TextInput
          placeholder="Digite seu nome"
          placeholderTextColor="#888"
          style={styles.input}
          onChangeText={setNome}
          value={nome}
        />
        <TextInput
          placeholder="E-mail"
          placeholderTextColor="#888"
          style={styles.input}
          keyboardType="email-address"
          onChangeText={setEmail}
          value={email}
        />
        <TextInput
          placeholder="Digite uma mensagem"
          placeholderTextColor="#888"
          style={[styles.input, styles.textArea]}
          multiline={true}
          numberOfLines={4}
          onChangeText={setMensagem}
          value={mensagem}
        />
      </View>



      <StatusBar style="light" />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    padding: 20,
    justifyContent: 'center', 
  },
  titulo: {
    color: 'red',
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',

  },
  form: {
    width: '100%',
    gap: 15, 
  },
  input: {
    backgroundColor: '#1a1a1a', 
    color: '#fff',
    height: 50,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#333',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
    paddingTop: 10,
  },

});
//n deu

export default Contato;