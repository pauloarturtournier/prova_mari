import React, { useState } from 'react';
import Perfil from '../Views/Perfil';
import Contato from '../Views/Contato';
import { View, Button } from 'react-native';

export default function App() {
  const [tela, setTela] = useState('perfil');

  return (
    <View>
        <Text>ola</Text>

    </View>
  );
}