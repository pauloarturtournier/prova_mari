import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View , Image} from 'react-native';




export default function Titulo() {
  return (
    <View style={styles.container}>
      <Text style={styles.red}>         Titulo</Text>
      <StatusBar style="auto" />

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 50,
  },
  red: {
    color: 'red',
    fontWeight : 'bold',
    fontSize: 50,
    alignContent:'center'
  },
});
